package com.example.sciflare

import android.content.ContentValues.TAG
import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.AdapterView
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : ComponentActivity() {
    private lateinit var db: AppDatabase

    var userdataList=ArrayList<UserDataModel>()
    private lateinit var Name_EditText: EditText
    private lateinit var Email_EditText: EditText
    private lateinit var Mobile_EditText: EditText
    private lateinit var gender_spinner : Spinner
    private lateinit var Register_Button: Button
    private lateinit var viewusers_Button: Button
    private lateinit var selectedGender:String
    private lateinit var  name:String
    private lateinit var  email:String
    private lateinit var  mobile:String



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
       setContentView(R.layout.activity_register)

        db = AppDatabase.getInstance(this)


        Name_EditText = findViewById(R.id.Name_EditText)
        Email_EditText = findViewById(R.id.Email_EditText)
        Mobile_EditText = findViewById(R.id.Mobile_EditText)
        gender_spinner= findViewById(R.id.gender_spinner)
        Register_Button= findViewById(R.id.Register_Button)
        viewusers_Button= findViewById(R.id.viewusers_Button)

        val genders = resources.getStringArray(R.array.genders_array)
        val adapter = GenderAdapter(this, genders)

        gender_spinner.adapter = adapter


        gender_spinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(
                parent: AdapterView<*>?,
                view: android.view.View?,
                position: Int,
                id: Long
            ) {
                 selectedGender = parent?.getItemAtPosition(position).toString()
                Toast.makeText(applicationContext, "Selected Gender: $selectedGender", Toast.LENGTH_SHORT).show()
            }

            override fun onNothingSelected(parent: AdapterView<*>?) {
            }
        }



        Register_Button.setOnClickListener {
             name = Name_EditText.text.toString()
             email = Email_EditText.text.toString()
             mobile = Mobile_EditText.text.toString()


            createuser(name, email, mobile,selectedGender)


            val intent = Intent(this, ShowDetails_Activity::class.java)

            startActivity(intent)


        }


        viewusers_Button.setOnClickListener {
            val name:String = Name_EditText.text.toString()
            val email:String = Email_EditText.text.toString()
            val mobile:String = Mobile_EditText.text.toString()


            getuseroverallData()


            val intent = Intent(this, ShowDetails_Activity::class.java)

            startActivity(intent)


        }





    }




    private fun getuseroverallData(){

        val call: Call<List<UserDataModel>> =ApiClient.getClient.getusersoveralllist()

        call.enqueue(object : Callback<List<UserDataModel>> {

            override fun onResponse(call: Call<List<UserDataModel>>?, response: Response<List<UserDataModel>>?) {
                userdataList.clear();
                userdataList.addAll(response!!.body()!!)

//                recyclerView.adapter?.notifyDataSetChanged()
                      Toast.makeText(applicationContext, response.toString(), Toast.LENGTH_SHORT).show()


//                for (signupDetails in userdataList) {
//                    signupViewModel.insert(signupDetails)
//                }
//
//                getDataFroDB()

// Now you have a list of User objects





//                val allUsers = db.userDao().getAllUsers()















//                val signupDetails = SignupDetails(username = username, email = email, password = password)
//                val signupDetails = SignupDetails(userdataList.get(i).).
//
//                signupViewModel.insert(signupDetails)




            }

            override fun onFailure(call: Call<List<UserDataModel>>?, t: Throwable?) {
                Toast.makeText(applicationContext, "onfailure", Toast.LENGTH_SHORT).show()

            }

        })

    }


//    private fun createuser(name:String, email:String, mobile:String,selectedGender:String){
//        val userData = UserrequestData(name, email, mobile, selectedGender)
//        val call = ApiClient.getClient.createUser(userData)
//        call.enqueue(object : Callback<UserCreaateResponseModel> {
//            override fun onResponse(call: Call<UserCreaateResponseModel>, response: Response<UserCreaateResponseModel>) {
//                if (response.isSuccessful) {
//                    val userResponse = response.body()
//                    Toast.makeText(applicationContext, userResponse.toString(), Toast.LENGTH_SHORT).show()
//
//                    userdataList.forEach { user ->
//                        println("User123: ${user.name}, ${user.email}, ${user.email}, ${user.gender}")
//
//                        val user = User(
//                            _id =user._id,
//                            name = user.name,
//                            email =  user.email,
//                            gender = user.gender,
//                            mobile = user.mobile
//
//                        )
//
////                        GlobalScope.launch(Dispatchers.IO) {
////
////                            // Insert each user into the database
////                            db.userDao().insert(user)
////
////                        }
//
//                        lifecycleScope.launch {
//                            try {
//                                db.userDao().insert(user)
//                                // Data inserted successfully
//                                Log.d(TAG, "Data inserted successfully")
//                            } catch (e: Exception) {
//                                // Failed to insert data
//                                Log.e(TAG, "Failed to insert data", e)
//                            }
//                        }
//
//
//
//
//                    }
//
//
//                    // Handle the user creation response
//                } else {
//                    // Handle unsuccessful response
//                }
//            }
//
//            override fun onFailure(call: Call<UserCreaateResponseModel>, t: Throwable) {
//                Toast.makeText(applicationContext, "onfailure", Toast.LENGTH_SHORT).show()
//            }
//        })
//    }


    private fun createuser(name: String, email: String, mobile: String, selectedGender: String) {
        val userData = UserrequestData(name, email, mobile, selectedGender)
        val call = ApiClient.getClient.createUser(userData)
        call.enqueue(object : Callback<UserCreaateResponseModel> {
            override fun onResponse(call: Call<UserCreaateResponseModel>, response: Response<UserCreaateResponseModel>) {
                if (response.isSuccessful) {
                    val userResponse = response.body()
                    Toast.makeText(applicationContext, userResponse.toString(), Toast.LENGTH_SHORT).show()

                    userdataList.forEach { user ->
                        println("User123: ${user.name}, ${user.email}, ${user.email}, ${user.gender}")

                        val user = User(
                            _id = user._id,
                            name = user.name,
                            email = user.email,
                            gender = user.gender,
                            mobile = user.mobile
                        )

                        // Launch a coroutine within the lifecycle scope
                        lifecycleScope.launch {
                            try {
                                // Insert user into the database
                                db.userDao().insert(user)
                                // Data inserted successfully
                                Log.d("checkinserteddata", "Data inserted successfully")
                            } catch (e: Exception) {
                                // Failed to insert data
                                Log.e("checkinserteddata", "Failed to insert data", e)
                            }
                        }
                    }
                } else {
                    // Handle unsuccessful response
                    Log.e(TAG, "Unsuccessful response: ${response.code()}")
                }
            }

            override fun onFailure(call: Call<UserCreaateResponseModel>, t: Throwable) {
                // Handle failure
                Log.e(TAG, "API call failed", t)
                Toast.makeText(applicationContext, "API call failed", Toast.LENGTH_SHORT).show()
            }
        })
    }




//    fun insertUserData(userList: List<User>) {
//        GlobalScope.launch(Dispatchers.IO) {
//            for (user in userList) {
//                // Insert each user into the database
//                db.userDao().insert(user)
//            }
//        }
//    }
}



