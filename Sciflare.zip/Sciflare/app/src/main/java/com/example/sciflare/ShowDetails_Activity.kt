package com.example.sciflare

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.sciflare.R.id.recycler_view
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class ShowDetails_Activity : ComponentActivity() {
    private lateinit var db: AppDatabase
    var dataList=ArrayList<User>()

    lateinit var recyclerView: RecyclerView


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_show_details)

        db = AppDatabase.getInstance(this)




        recyclerView = findViewById(recycler_view)



        GlobalScope.launch(Dispatchers.IO) {
            val allUsers = db.userDao().getAllUsers()
            withContext(Dispatchers.Main) {
                // Update UI on the main thread
//                recyclerView.adapter=  DataAdpter(users, this)

                recyclerView.adapter= DataAdpter(dataList,this@ShowDetails_Activity)
                recyclerView.layoutManager= LinearLayoutManager(this@ShowDetails_Activity, LinearLayoutManager.VERTICAL,false)



            }
        }



    }
}