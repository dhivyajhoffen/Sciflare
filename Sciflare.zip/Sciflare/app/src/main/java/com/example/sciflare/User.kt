package com.example.sciflare

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user")

/*data class User(
//    @PrimaryKey(autoGenerate = true)
    @PrimaryKey
    val _id: String,
    val name: String,
    val email: String,
    val mobile: String,
    val gender: String
)*/
data class User(
    @PrimaryKey
    val _id: String,
    var name: String,
    val email: String,
    val mobile: String,
    val gender: String
)



